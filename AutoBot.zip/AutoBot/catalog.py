cart_Main_Name = {
            #BLUETOOTH адаптеры / FM модуляторы
             1:'AUX Bluetooth Ресивер ACV BTR-35А',
             2:'FM-трансмиттер ACV FMT-122B с Bluetooth/AUX/MicroSD',
             3:'iO BTA PODC Bluetooth Stereo',
            #Акустика
             4:'5x7: DL Audio Barracuda 57',
             5:'20: DL Audio Gryphon Lite 200 V.2 эстрадная акустика',
             6:'16: DL Audio Gryphon Lite 165 V.2 эстрадная акустика',
            #Кабель AUX / USB / VIDEO
             7:'Переходник Kixc Mini Jack на 2RCA',
             8:'Кабель USB-MICRO USB URAL DECIBEL USB-MICRO USB 15',
             9:'Кабель HDMI 1.5мерта',
            #ПОДОГРЕВЫ / ОТОПИТЕЛИ / АВТОТЕПЛО
             10:'Подогрев сидений ACV HS-02 на 2 места разнесенные кнопки',
             11:'Автономный отопитель Вебасто/Webasto Thermo Top Start',
             12:'Утеплитель двигателя STP HeatShield 2в1 XL (1,35x0,8м)',
            }

cart_Main_Item = {
             cart_Main_Name[1]:500,
             cart_Main_Name[2]:890,
             cart_Main_Name[3]:1750,
             cart_Main_Name[4]:2790,
             cart_Main_Name[5]:3290,
             cart_Main_Name[6]:2490,
             cart_Main_Name[7]:150,
             cart_Main_Name[8]:300,
             cart_Main_Name[9]:280,
             cart_Main_Name[10]:7300,
             cart_Main_Name[11]:59990,
             cart_Main_Name[12]:2500,
             }
